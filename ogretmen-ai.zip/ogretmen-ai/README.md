# ÖğretmenAI 🎓

Yapay zeka destekli öğretmen araç seti.

## Kurulum

```bash
npm install
npm start
```

## Vercel ile Yayınlama

1. Bu repoyu GitHub'a yükleyin
2. [vercel.com](https://vercel.com) adresine GitHub ile giriş yapın
3. "Import Project" ile bu repoyu seçin
4. Otomatik olarak yayınlanacaktır

## Araçlar

- 📚 Ders Planı Oluşturucu
- 📝 Sınav Hazırlama
- ✅ Rubrik / Değerlendirme
- 🎯 Etkinlik Tasarlama
- 💬 Veli Mektubu
- 🧩 Bireyselleştirme
