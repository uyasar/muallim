import { useState, useEffect, useRef } from "react";

const API_URL = "https://api.anthropic.com/v1/messages";

async function askClaude(systemPrompt, userMessage) {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 2048,
      system: systemPrompt,
      messages: [{ role: "user", content: userMessage }],
    }),
  });
  const data = await res.json();
  return data.content?.map((b) => b.text || "").join("\n") || "Bir hata oluştu.";
}

function downloadAsWord(content, filename) {
  const converted = content
    .replace(/^### (.+)$/gm, '<h3 style="color:#1a1a2e;font-family:Cambria,serif;font-size:14pt;margin:18pt 0 8pt;">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 style="color:#1a1a2e;font-family:Cambria,serif;font-size:16pt;margin:22pt 0 10pt;">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 style="color:#1a1a2e;font-family:Cambria,serif;font-size:20pt;margin:26pt 0 12pt;">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/\*(.+?)\*/g, '<i>$1</i>')
    .replace(/^- (.+)$/gm, '<li style="margin:4pt 0;font-size:11pt;">$1</li>')
    .replace(/^(\d+)\. (.+)$/gm, '<li style="margin:4pt 0;font-size:11pt;">$2</li>')
    .replace(/\n{2,}/g, '</p><p style="font-family:Calibri,sans-serif;font-size:11pt;line-height:1.6;margin:6pt 0;color:#333;">')
    .replace(/\n/g, '<br/>');

  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office"
          xmlns:w="urn:schemas-microsoft-com:office:word"
          xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta charset="utf-8">
      <style>
        @page { margin: 2.5cm; }
        body { font-family: Calibri, sans-serif; font-size: 11pt; line-height: 1.6; color: #333; }
        h1 { color: #1a1a2e; font-family: Cambria, serif; font-size: 20pt; border-bottom: 2pt solid #e63946; padding-bottom: 8pt; }
        h2 { color: #1a1a2e; font-family: Cambria, serif; font-size: 16pt; margin-top: 22pt; }
        h3 { color: #1a1a2e; font-family: Cambria, serif; font-size: 14pt; }
        table { border-collapse: collapse; width: 100%; margin: 12pt 0; }
        td, th { border: 1px solid #ccc; padding: 8pt; font-size: 10pt; }
        th { background: #f0f0f5; font-weight: bold; }
        li { margin: 4pt 0; }
        .footer { margin-top: 30pt; padding-top: 10pt; border-top: 1px solid #ddd; font-size: 9pt; color: #999; text-align: center; }
      </style>
    </head>
    <body>
      <p style="font-family:Calibri,sans-serif;font-size:11pt;line-height:1.6;margin:6pt 0;color:#333;">
        ${converted}
      </p>
      <div class="footer">ÖğretmenAI ile oluşturulmuştur</div>
    </body>
    </html>`;

  const blob = new Blob([html], { type: "application/msword" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${filename}.doc`;
  a.click();
  URL.revokeObjectURL(url);
}

const TOOLS = [
  {
    id: "lesson", icon: "📚", title: "Ders Planı", desc: "MEB müfredatına uygun detaylı ders planları",
    accent: "#E63946", bg: "linear-gradient(135deg,#E63946,#FF6B6B)",
    fields: [
      { key: "subject", label: "Ders / Konu", ph: "Matematik — Kesirler" },
      { key: "grade", label: "Sınıf Seviyesi", ph: "5. sınıf" },
      { key: "duration", label: "Süre", ph: "40 dakika" },
    ],
    system: "Sen deneyimli bir Türk eğitim uzmanısın. MEB müfredatına uygun, detaylı ders planı hazırla. Kazanımlar, etkinlikler, materyaller, değerlendirme ve zaman çizelgesi ekle. Markdown formatında, başlıklar ve listeler kullan. Türkçe yanıt ver.",
    prompt: (f) => `${f.grade} seviyesinde, ${f.subject} konusunda ${f.duration} süreli bir ders planı hazırla.`,
  },
  {
    id: "exam", icon: "📝", title: "Sınav Oluştur", desc: "Bloom taksonomisine uygun sınav ve cevap anahtarı",
    accent: "#457B9D", bg: "linear-gradient(135deg,#457B9D,#6DB3D5)",
    fields: [
      { key: "subject", label: "Ders / Konu", ph: "Fen Bilimleri — Hücre" },
      { key: "grade", label: "Sınıf Seviyesi", ph: "7. sınıf" },
      { key: "qcount", label: "Soru Sayısı ve Tipleri", ph: "10 çoktan seçmeli, 5 açık uçlu" },
    ],
    system: "Sen sınav hazırlama uzmanısın. Bloom taksonomisine uygun, farklı zorluk seviyelerinde sorular hazırla. Cevap anahtarını da ekle. Markdown formatında düzenle. Türkçe yanıt ver.",
    prompt: (f) => `${f.grade} seviyesinde ${f.subject} konusunda ${f.qcount} içeren bir sınav hazırla.`,
  },
  {
    id: "rubric", icon: "✅", title: "Rubrik Oluştur", desc: "Analitik değerlendirme rubriği hazırlama",
    accent: "#2A9D8F", bg: "linear-gradient(135deg,#2A9D8F,#52D1C2)",
    fields: [
      { key: "task", label: "Ödev / Proje", ph: "Çevre kirliliği araştırma ödevi" },
      { key: "grade", label: "Sınıf Seviyesi", ph: "8. sınıf" },
      { key: "criteria", label: "Kriterler (opsiyonel)", ph: "İçerik, sunum, kaynakça" },
    ],
    system: "Sen değerlendirme uzmanısın. Detaylı analitik rubrik oluştur. Her kriter için 4 performans düzeyi belirle. Tablo formatında markdown kullan. Türkçe yanıt ver.",
    prompt: (f) => `${f.grade} seviyesinde "${f.task}" için rubrik oluştur. ${f.criteria ? "Kriterler: " + f.criteria : ""}`,
  },
  {
    id: "activity", icon: "🎯", title: "Etkinlik Tasarla", desc: "İnteraktif ve yaratıcı sınıf etkinlikleri",
    accent: "#E9C46A", bg: "linear-gradient(135deg,#E9C46A,#F4D98C)",
    fields: [
      { key: "subject", label: "Ders / Konu", ph: "Türkçe — Deyimler" },
      { key: "grade", label: "Sınıf Seviyesi", ph: "4. sınıf" },
      { key: "type", label: "Etkinlik Türü", ph: "Oyun, grup çalışması, drama" },
    ],
    system: "Sen yaratıcı eğitim tasarımcısısın. Öğrencilerin aktif katılımını sağlayacak etkinlikler tasarla. Malzeme, kurallar, süre ve değerlendirme ekle. Markdown formatında. Türkçe yanıt ver.",
    prompt: (f) => `${f.grade} seviyesinde ${f.subject} konusu için ${f.type || "interaktif"} etkinlik tasarla.`,
  },
  {
    id: "parent", icon: "💬", title: "Veli Mektubu", desc: "Profesyonel veli bilgilendirme yazıları",
    accent: "#8338EC", bg: "linear-gradient(135deg,#8338EC,#A66BF0)",
    fields: [
      { key: "topic", label: "Konu", ph: "Gezi bildirimi, karne bilgilendirme" },
      { key: "tone", label: "Ton", ph: "Resmi, samimi, bilgilendirici" },
      { key: "details", label: "Ek Detaylar", ph: "Tarih, yer, gerekli bilgiler" },
    ],
    system: "Sen okul iletişim uzmanısın. Velilere yönelik profesyonel bilgilendirme mektupları yaz. Markdown formatında. Türkçe yanıt ver.",
    prompt: (f) => `"${f.topic}" konusunda ${f.tone || "profesyonel"} tonda veli mektubu yaz. Detaylar: ${f.details || "Genel"}`,
  },
  {
    id: "diff", icon: "🧩", title: "Bireyselleştirme", desc: "Farklı öğrenme ihtiyaçlarına göre uyarlama",
    accent: "#FF6B35", bg: "linear-gradient(135deg,#FF6B35,#FF9A6C)",
    fields: [
      { key: "subject", label: "Konu", ph: "Matematik — Ondalık sayılar" },
      { key: "grade", label: "Sınıf Seviyesi", ph: "6. sınıf" },
      { key: "needs", label: "Öğrenci İhtiyaçları", ph: "Öğrenme güçlüğü, üstün zeka" },
    ],
    system: "Sen özel eğitim ve bireyselleştirme uzmanısın. Konuyu farklı öğrenme ihtiyaçlarına uyarla. Her seviye için etkinlik, materyal ve değerlendirme öner. Markdown formatında. Türkçe yanıt ver.",
    prompt: (f) => `${f.grade} seviyesinde ${f.subject} konusunu ${f.needs} olan öğrenciler için bireyselleştir.`,
  },
];

export default function App() {
  const [view, setView] = useState("home");
  const [toolId, setToolId] = useState(null);
  const [fields, setFields] = useState({});
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [typed, setTyped] = useState("");
  const [copied, setCopied] = useState(false);
  const resRef = useRef(null);

  const tool = TOOLS.find((t) => t.id === toolId);

  useEffect(() => {
    if (!result) { setTyped(""); return; }
    let i = 0; setTyped("");
    const iv = setInterval(() => {
      if (i < result.length) { setTyped((p) => p + result[i]); i++; }
      else clearInterval(iv);
    }, 5);
    return () => clearInterval(iv);
  }, [result]);

  const generate = async () => {
    if (!tool) return;
    setLoading(true); setResult("");
    try {
      const r = await askClaude(tool.system, tool.prompt(fields));
      setResult(r);
      setTimeout(() => resRef.current?.scrollIntoView({ behavior: "smooth" }), 300);
    } catch { setResult("Hata oluştu. Tekrar deneyin."); }
    setLoading(false);
  };

  const open = (id) => { setToolId(id); setFields({}); setResult(""); setView("tool"); };
  const home = () => { setView("home"); setToolId(null); setResult(""); setFields({}); };

  const canGenerate = tool?.fields.some((f) => fields[f.key]?.trim());

  const copyResult = () => {
    navigator.clipboard?.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={S.root}>
      <style>{CSS}</style>
      {/* Decorative elements */}
      <div style={S.meshTop} />
      <div style={S.meshBot} />
      <div style={S.dotGrid} />

      <div style={S.container}>
        {/* NAV */}
        <nav style={S.nav}>
          <div style={S.navLeft} onClick={home}>
            <div style={S.logo}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#E63946" strokeWidth="2.5" strokeLinecap="round"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>
            </div>
            <span style={S.brand}>ÖğretmenAI</span>
          </div>
          {view === "tool" && (
            <button onClick={home} style={S.navBack}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6"/></svg>
              Araçlar
            </button>
          )}
        </nav>

        {view === "home" ? (
          <div style={{ animation: "fadeIn .5s ease" }}>
            {/* HERO */}
            <div style={S.hero}>
              <div style={S.heroTag}>✦ YZ DESTEKLİ EĞİTİM ARAÇLARI</div>
              <h1 style={S.heroTitle}>
                Öğretmenler için<br/>
                <span style={S.heroAccent}>akıllı</span> araç seti
              </h1>
              <p style={S.heroSub}>
                Ders planlarından sınav sorularına, veli mektuplarından bireyselleştirmeye — yapay zeka ile dakikalar içinde profesyonel içerikler oluşturun.
              </p>
            </div>

            {/* TOOL GRID */}
            <div style={S.grid}>
              {TOOLS.map((t, i) => (
                <div key={t.id} className="tool-card" style={{ ...S.card, animationDelay: `${i * 0.07}s` }} onClick={() => open(t.id)}>
                  <div style={{ ...S.cardIcon, background: t.bg }}>{t.icon}</div>
                  <div style={{ flex: 1 }}>
                    <h3 style={S.cardTitle}>{t.title}</h3>
                    <p style={S.cardDesc}>{t.desc}</p>
                  </div>
                  <div className="card-arrow" style={S.cardArrow}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                  </div>
                </div>
              ))}
            </div>

            {/* STATS */}
            <div style={S.stats}>
              {[["6", "YZ Aracı"], ["∞", "Sınırsız Üretim"], ["📄", "Word İndirme"]].map(([n, l], i) => (
                <div key={i} style={S.stat}>
                  <div style={S.statNum}>{n}</div>
                  <div style={S.statLabel}>{l}</div>
                </div>
              ))}
            </div>
          </div>
        ) : tool ? (
          <div style={{ animation: "fadeIn .4s ease" }}>
            {/* TOOL HEADER */}
            <div style={S.toolHeader}>
              <div style={{ ...S.toolIcon, background: tool.bg }}>{tool.icon}</div>
              <div>
                <h2 style={S.toolTitle}>{tool.title}</h2>
                <p style={S.toolDesc}>{tool.desc}</p>
              </div>
            </div>

            {/* FORM */}
            <div style={S.formCard}>
              {tool.fields.map((f) => (
                <div key={f.key} style={S.fieldGroup}>
                  <label style={S.label}>{f.label}</label>
                  <input
                    className="field-input"
                    style={S.input}
                    placeholder={f.ph}
                    value={fields[f.key] || ""}
                    onChange={(e) => setFields({ ...fields, [f.key]: e.target.value })}
                  />
                </div>
              ))}
              <button
                className="gen-btn"
                style={{ ...S.genBtn, background: tool.bg, opacity: !canGenerate || loading ? 0.5 : 1 }}
                onClick={generate}
                disabled={!canGenerate || loading}
              >
                {loading ? (
                  <span style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span className="spinner" />
                    Oluşturuluyor...
                  </span>
                ) : (
                  <span>{tool.icon} Oluştur</span>
                )}
              </button>
            </div>

            {/* LOADING */}
            {loading && (
              <div style={S.loadingWrap}>
                <div className="progress-bar" style={{ background: tool.bg }} />
                <p style={S.loadingText}>Yapay zeka içeriğinizi hazırlıyor...</p>
              </div>
            )}

            {/* RESULT */}
            {result && (
              <div ref={resRef} style={S.resultWrap}>
                <div style={S.resultHeader}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ ...S.resultDot, background: tool.accent }} />
                    <span style={{ ...S.resultLabel, color: tool.accent }}>Sonuç</span>
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button className="action-btn" style={S.actionBtn} onClick={copyResult}>
                      {copied ? "✓ Kopyalandı" : "Kopyala"}
                    </button>
                    <button
                      className="action-btn download-btn"
                      style={{ ...S.actionBtn, ...S.downloadBtn, borderColor: tool.accent, color: tool.accent }}
                      onClick={() => downloadAsWord(result, `${tool.title.replace(/\s/g, "_")}_${new Date().toLocaleDateString("tr-TR")}`)}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
                      Word İndir
                    </button>
                  </div>
                </div>
                <div style={S.resultBody}>{typed}<span className="cursor">|</span></div>
              </div>
            )}
          </div>
        ) : null}

        <footer style={S.footer}>
          <span>ÖğretmenAI</span> — Yapay zeka ile eğitimi güçlendirin
        </footer>
      </div>
    </div>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&display=swap');

* { box-sizing: border-box; margin: 0; padding: 0; }

@keyframes fadeIn { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
@keyframes slideCard { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0} }
@keyframes spin { to{transform:rotate(360deg)} }
@keyframes progress { 0%{width:0} 50%{width:70%} 100%{width:95%} }

.cursor { animation: pulse 1s infinite; color: #E63946; font-weight: 300; }

.tool-card {
  background: #fff;
  border: 1px solid #f0ece6;
  border-radius: 18px;
  padding: 22px 24px;
  display: flex;
  align-items: center;
  gap: 18px;
  cursor: pointer;
  transition: all .3s cubic-bezier(.4,0,.2,1);
  animation: slideCard .5s ease both;
}
.tool-card:hover {
  border-color: #e0dbd3;
  box-shadow: 0 12px 40px rgba(0,0,0,0.06);
  transform: translateY(-3px);
}
.tool-card:hover .card-arrow { opacity: 1; transform: translateX(0); }

.field-input {
  width: 100%;
  padding: 14px 18px;
  background: #faf9f6;
  border: 1.5px solid #ece8e0;
  border-radius: 12px;
  font-family: 'Outfit', sans-serif;
  font-size: 14px;
  color: #1a1a2e;
  outline: none;
  transition: all .25s;
}
.field-input:focus {
  border-color: #ccc5b9;
  background: #fff;
  box-shadow: 0 0 0 4px rgba(230,57,70,0.06);
}
.field-input::placeholder { color: #bbb5aa; }

.gen-btn {
  width: 100%;
  padding: 16px;
  border: none;
  border-radius: 14px;
  color: #fff;
  font-family: 'Outfit', sans-serif;
  font-weight: 700;
  font-size: 15px;
  cursor: pointer;
  transition: all .3s;
  letter-spacing: .2px;
}
.gen-btn:hover:not(:disabled) { transform: translateY(-2px); box-shadow: 0 8px 28px rgba(0,0,0,0.15); }

.spinner {
  width: 18px; height: 18px;
  border: 2.5px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin .7s linear infinite;
  display: inline-block;
}

.progress-bar {
  height: 3px;
  border-radius: 3px;
  animation: progress 8s ease-out forwards;
  opacity: .6;
}

.action-btn {
  padding: 8px 16px;
  border-radius: 10px;
  font-family: 'Outfit', sans-serif;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all .2s;
  background: #faf9f6;
  border: 1.5px solid #ece8e0;
  color: #666;
  display: flex;
  align-items: center;
  gap: 6px;
}
.action-btn:hover { background: #f0ece6; }
.download-btn:hover { opacity: .85; }
`;

const S = {
  root: {
    minHeight: "100vh",
    background: "#FDFCF9",
    color: "#1a1a2e",
    fontFamily: "'Outfit', sans-serif",
    position: "relative",
    overflow: "hidden",
  },
  meshTop: {
    position: "fixed", top: -200, right: -200,
    width: 600, height: 600,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(230,57,70,0.06) 0%, transparent 70%)",
    pointerEvents: "none", zIndex: 0,
  },
  meshBot: {
    position: "fixed", bottom: -300, left: -200,
    width: 700, height: 700,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(69,123,157,0.05) 0%, transparent 70%)",
    pointerEvents: "none", zIndex: 0,
  },
  dotGrid: {
    position: "fixed", inset: 0,
    backgroundImage: "radial-gradient(circle, #e0dbd3 0.7px, transparent 0.7px)",
    backgroundSize: "32px 32px",
    opacity: 0.3,
    pointerEvents: "none", zIndex: 0,
  },
  container: {
    position: "relative", zIndex: 1,
    maxWidth: 880, margin: "0 auto", padding: "0 20px",
  },
  nav: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "24px 0", borderBottom: "1px solid #f0ece6",
    marginBottom: 40,
  },
  navLeft: { display: "flex", alignItems: "center", gap: 12, cursor: "pointer" },
  logo: {
    width: 42, height: 42, borderRadius: 12,
    background: "#FFF5F5", border: "1.5px solid #fde8e8",
    display: "flex", alignItems: "center", justifyContent: "center",
  },
  brand: { fontFamily: "'Libre Baskerville', serif", fontWeight: 700, fontSize: 18, color: "#1a1a2e" },
  navBack: {
    display: "flex", alignItems: "center", gap: 6,
    background: "none", border: "1.5px solid #ece8e0",
    borderRadius: 10, padding: "8px 16px",
    fontFamily: "'Outfit', sans-serif", fontSize: 13, fontWeight: 600,
    color: "#888", cursor: "pointer",
  },
  hero: { textAlign: "center", marginBottom: 56, animation: "fadeIn .6s ease" },
  heroTag: {
    display: "inline-block",
    padding: "8px 20px", borderRadius: 100,
    background: "#FFF5F5", border: "1px solid #fde8e8",
    fontSize: 11, fontWeight: 700, letterSpacing: 1.5,
    color: "#E63946", marginBottom: 24,
  },
  heroTitle: {
    fontFamily: "'Libre Baskerville', serif",
    fontSize: 44, fontWeight: 700, lineHeight: 1.15,
    color: "#1a1a2e", marginBottom: 18,
  },
  heroAccent: {
    fontStyle: "italic", color: "#E63946",
    textDecoration: "underline", textDecorationColor: "rgba(230,57,70,0.2)",
    textUnderlineOffset: 6,
  },
  heroSub: {
    fontSize: 16, lineHeight: 1.7, color: "#8a8578",
    maxWidth: 520, margin: "0 auto",
  },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(380px, 1fr))", gap: 14 },
  card: { /* in CSS */ },
  cardIcon: {
    width: 48, height: 48, borderRadius: 14,
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 22, flexShrink: 0,
  },
  cardTitle: { fontWeight: 700, fontSize: 15, color: "#1a1a2e", marginBottom: 3 },
  cardDesc: { fontSize: 13, color: "#9a9488", lineHeight: 1.4 },
  cardArrow: { opacity: 0, transform: "translateX(-8px)", transition: "all .3s", color: "#bbb" },
  stats: {
    display: "flex", justifyContent: "center", gap: 48,
    marginTop: 56, padding: "32px 0",
    borderTop: "1px solid #f0ece6",
  },
  stat: { textAlign: "center" },
  statNum: { fontFamily: "'Libre Baskerville', serif", fontSize: 28, fontWeight: 700, color: "#1a1a2e" },
  statLabel: { fontSize: 12, color: "#9a9488", marginTop: 4, fontWeight: 500 },
  toolHeader: {
    display: "flex", alignItems: "center", gap: 20, marginBottom: 32,
    animation: "fadeIn .4s ease",
  },
  toolIcon: {
    width: 56, height: 56, borderRadius: 16,
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 28, flexShrink: 0,
  },
  toolTitle: { fontFamily: "'Libre Baskerville', serif", fontSize: 24, fontWeight: 700, color: "#1a1a2e" },
  toolDesc: { fontSize: 14, color: "#9a9488", marginTop: 2 },
  formCard: {
    background: "#fff",
    border: "1px solid #f0ece6",
    borderRadius: 20, padding: 32,
    boxShadow: "0 4px 20px rgba(0,0,0,0.03)",
  },
  fieldGroup: { marginBottom: 20 },
  label: { display: "block", fontSize: 13, fontWeight: 600, color: "#6b6560", marginBottom: 8 },
  input: { /* in CSS */ },
  genBtn: { marginTop: 8 },
  loadingWrap: { marginTop: 24 },
  loadingText: { fontSize: 13, color: "#bbb5aa", textAlign: "center", marginTop: 12 },
  resultWrap: {
    marginTop: 28, background: "#fff",
    border: "1px solid #f0ece6", borderRadius: 20,
    overflow: "hidden", animation: "fadeIn .5s ease",
    boxShadow: "0 4px 20px rgba(0,0,0,0.03)",
  },
  resultHeader: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "18px 28px",
    borderBottom: "1px solid #f0ece6",
    flexWrap: "wrap", gap: 12,
  },
  resultDot: { width: 8, height: 8, borderRadius: "50%" },
  resultLabel: { fontWeight: 700, fontSize: 14 },
  actionBtn: { /* in CSS */ },
  downloadBtn: { background: "transparent" },
  resultBody: {
    padding: 28, fontSize: 14, lineHeight: 1.9,
    color: "#444", whiteSpace: "pre-wrap",
    fontFamily: "'Outfit', sans-serif",
    maxHeight: 600, overflowY: "auto",
  },
  footer: {
    textAlign: "center", marginTop: 64, paddingTop: 24, paddingBottom: 32,
    borderTop: "1px solid #f0ece6",
    fontSize: 13, color: "#c5c0b8",
  },
};
